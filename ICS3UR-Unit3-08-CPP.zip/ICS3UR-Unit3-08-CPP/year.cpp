// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This program identifies a leap year

#include <iostream>
#include <string>

int main() {
    int year;
    std::string yearAsString;

    // input
    std::cout << "Will it be a leap year?" <<
    std::endl;
    std::cout << "Enter a leap year: ";
    std::cin >> yearAsString;
    std::cout << "" << std::endl;

    try {
        year = std::stoi(yearAsString);

        if (year % 4 == 0) {
            if (year % 100 == 0) {
                if (year % 400 == 0) {
                    std::cout << year << " is a leap year" << std::endl;
                } else {
                    std::cout << year << " isn't a leap year" << std::endl;
                }
            } else {
                std::cout << year << " is a leap year" << std::endl;
            }
        } else {
            std::cout << year << " isn't a leap year" << std::endl;
        }
    } catch (std::invalid_argument) {
        std::cout << "ERROR: THAT IS NOT A VALID INPUT" << std::endl;
    }
}
